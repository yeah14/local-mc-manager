@echo off
cd /d "%~dp0"
start "" "%~dp0McPanel.exe" --client
